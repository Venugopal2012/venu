package com.myflight.deploymentrules;

public interface DeploymentRule {
	public boolean execute();
}