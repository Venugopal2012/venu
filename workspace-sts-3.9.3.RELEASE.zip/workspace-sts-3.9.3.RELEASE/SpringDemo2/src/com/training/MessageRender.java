package com.training;

public class MessageRender {
	MessageProvider provider;
	//public setMessageProvider{
		//return 
	//}
}
