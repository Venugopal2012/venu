package com.training;

public interface MessageProvider {

}
