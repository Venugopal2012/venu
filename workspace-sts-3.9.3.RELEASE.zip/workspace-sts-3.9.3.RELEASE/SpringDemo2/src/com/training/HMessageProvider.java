package com.training;

public class HMessageProvider implements MessageProvider {
	public String getMessage() {
		return "Hello";
	}
}
