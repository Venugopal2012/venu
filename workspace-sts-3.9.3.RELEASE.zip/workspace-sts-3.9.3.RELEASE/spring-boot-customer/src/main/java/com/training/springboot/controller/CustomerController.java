package com.training.springboot.controller;

import java.util.Iterator;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.springboot.entity.Customer1;
import com.training.springboot.repo.CustomerRepository;

@RestController
public class CustomerController {
	@Autowired
	private CustomerRepository repository;
	@RequestMapping("/customers")
	public Iterator <Customer1> getAll(){
		return repository.findAll().iterator();
	}
	@RequestMapping("/customer/{id}")
	public Optional <Customer1> getById(@PathVariable("id") int customerId){
		//return repository.findById(customerId);
		return repository.findById(customerId);
	}
	@PostMapping("/customers")
	public void addNewCustomer(@RequestBody Customer1 customer) {
		repository.save(customer);
	}
	@PutMapping("/customers")
	public void updateCustomer(@RequestBody Customer1 customer) {
		repository.save(customer);
	}
	//public void deleteById(@PathVariable("id")int id) {
		//repository.delete(Customer1);
	//}
}
