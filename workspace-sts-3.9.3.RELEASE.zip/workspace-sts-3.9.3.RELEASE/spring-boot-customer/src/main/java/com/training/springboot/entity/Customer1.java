package com.training.springboot.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;


@Entity
public class Customer1 {

	public Customer1()
	{
		
	}
	
	public Customer1(int customerId,String fName,String sName,String emailId)
	{
		super();
		this.fName=fName;
		this.sName=sName;
		this.emailId=emailId;
		this.customerId=customerId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	@Id
	private int customerId;

	private String emailId;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	private String fName;
	private String sName;
	
}
