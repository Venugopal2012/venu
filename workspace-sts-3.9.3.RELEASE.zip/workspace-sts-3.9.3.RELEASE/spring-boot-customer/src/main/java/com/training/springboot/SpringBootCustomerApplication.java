package com.training.springboot;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
//import org.springframework.stereotype.Repository;

import com.training.springboot.entity.Customer1;
import com.training.springboot.repo.CustomerRepository;

@SpringBootApplication
public class SpringBootCustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCustomerApplication.class, args);
	}
	
	@Bean
	CommandLineRunner init(CustomerRepository repository) {
		return (evt)->{
			repository.save(new Customer1(1,"suraj","singh","suraj.gmail.com"));
			repository.save(new Customer1(102,"sura","ingh","raj.gmail.com"));
		};
	}
	
}
