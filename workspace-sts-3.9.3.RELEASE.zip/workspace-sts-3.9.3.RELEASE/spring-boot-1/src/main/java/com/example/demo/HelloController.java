package com.example.demo;

import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	//@RequestMapping("/hello")
	@RequestMapping("/")
	
	public Greet sayHello()
	{
		return new Greet("hello world");
	}
	@RequestMapping("/hello")
	public Greet sayHello2()
	{
		Greet greet= new Greet("hello world !");
		greet.add(ControllerLinkBuilder.linkTo(ControllerLinkBuilder.methodOn(HelloController.class).sayHello2()).withRel();
	}
	//@RequestMapping("/hello")
	
}
