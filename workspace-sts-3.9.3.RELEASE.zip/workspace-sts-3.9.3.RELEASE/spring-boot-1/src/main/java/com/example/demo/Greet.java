package com.example.demo;

import org.springframework.hateoas.ResourceSupport;

public class Greet extends ResourceSupport {
	private String message;
	

	public Greet() {
		// TODO Auto-generated constructor stub
	}
	public Greet(String string) {
		super();
		this.message=message;
	}
	public String getMessage(){
		return message;
	}
	public void setMessage(String message) {
		this.message=message;
	}
}
